<!-- Include Header -->
<?php
require_once 'header.php';
?>


<div class="container-fluid">
    <div class="pagetitle">
        <a>Welcome To My Personal Space</a>
    </div>
</div>
<div class="container-fluid" style="margin-top: 65px">

    <div class="box">

        <div class="contents">
            <h class="text-center">
                </h1>
                <h3>
                    We are Here To Provide You With the Perfect Pet
                    <small class="text-muted">So Help Us Make Your Family Bigger By Contacting Us. </small>
                </h3>


                <ul class="list-group">
                    <li Class="text-dark" class="display-1" class="list-group-item">You Can Contact Us throgh:</li>

                    <li class="list-group-item list-group-item-secondary">Dogs Adoption Phone Number:8316723071.</li>
                    <li class="list-group-item list-group-item-secondary">Cats Adoption Phone Number:8046644445.</li>
                    <li class="list-group-item list-group-item-secondary">Exotics Adoption Phone Number:8045633335..</li>
                    <li class="list-group-item list-group-item-secondary">Email:Animalwebsite@gmail.com.</li>
                    <li class="list-group-item list-group-item-secondary">Fax:13235551234@efaxsend.com.</li>
                </ul>

                </br>
        </div>
    </div>
</div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/js/bootstrap.min.js" integrity="sha384-o+RDsa0aLu++PJvFqy8fFScvbHFLtbvScb8AjopnFD+iEQ7wo/CG0xlczd+2O/em"
        crossorigin="anonymous"></script>
</body>

</html>