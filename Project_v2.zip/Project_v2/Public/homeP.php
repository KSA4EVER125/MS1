<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/css/bootstrap.min.css" integrity="sha384-Smlep5jCw/wG7hdkwQ/Z5nLIefveQRIY9nfy6xoR1uRYBtpZgI6339F5dgvm/e9B"
        crossorigin="anonymous">
    <title>Welcome to Our Home Page</title>
</head>

<body>

    <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="homeP.html">Paws to Care</a>
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive"
                aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="active" /li>
                        <li class="nav-item">
                            <a class="nav-link" href="homeP.html">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="aboutP.html">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contactP.html">Contact Us</a>
                        </li>
                        

            </div>
        </div>
    </nav>

    <div class="pagetitle">
        <a>Welcome To My Personal Space</a>
    </div>
    <div class="container-fluid">

        <div class="box">
            <img class="center-block" src="images/Giraffe_standing.jpg" alt="Chania" width="1300" height="600">
            <div class="contents">
                <h class="text-center">
                    </h1>
                    <h3>
                        Come Adopt A Pet
                        <small class="text-muted">And Togather Lets Make The World A better place</small>
                    </h3>
                    <ul class="list-group">
                        <li Class="text-dark" class="font-weight-bold" class="list-group-item">Famous Qoutes About Pets</li>

                        <li class="list-group-item list-group-item-secondary">"Until one has loved an animal, a part of one's soul remains unawakened." ― Anatole France</li>
                        <li class="list-group-item list-group-item-secondary">"If having a soul means being able to feel love and loyalty and gratitude, then animals are better
                            off than a lot of humans."―James Herriot</li>
                        <li class="list-group-item list-group-item-secondary">"The greatness of a nation and its moral progress can be judged by the way its animals are treated."
                            ― Mahatma Gandhi</li>
                        <li class="list-group-item list-group-item-secondary">"An animal's eyes have the power to speak a great language." ― Martin Buber</li>
                        <li class="list-group-item list-group-item-secondary">"“I care not for a man's religion whose dog and cat are not the better for it.” ― Abraham Lincoln</li>
                    </ul>

                    </br>
            </div>
        </div>
    </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/js/bootstrap.min.js" integrity="sha384-o+RDsa0aLu++PJvFqy8fFScvbHFLtbvScb8AjopnFD+iEQ7wo/CG0xlczd+2O/em"
        crossorigin="anonymous"></script>
</body>

</html>