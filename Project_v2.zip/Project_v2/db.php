<?php

/**
 * Contains constants for the database connection, this is useful
 * to handle the database configuration at one place through out
 * the application.   
 */

define("HOST", "localhost");
define("USER", "root");
define("PASSWORD", "");
define("DBNAME", "pets");

/**
 * Function to get Connection to the database. 
 */
function GetConnection()
{
     // DB Connection
    $conn = new mysqli(HOST, USER, PASSWORD, DBNAME); 
    
    // Check connection
    if($conn->connect_error) {
        die("Connection to Database failed: " . $conn->connect_error);
    }
    
    return $conn;
}

/**
 * Function to get connection without database - will be useful
 * to create database
 */
function GetConnectionBeforeDatabase()
{
    // DB Connection
    $conn = new mysqli(HOST, USER, PASSWORD); 
    
    // Check connection
    if($conn->connect_error) {
        die("Connection to Database failed: " . $conn->connect_error);
    }
    
    return $conn;
}

/**
 * Function to get a member with given user name
 * 
 * @param type $username
 */
function GetMember($username) {
    
    //Query
    $query = "SELECT UserName from users where username=?";

    //Connection Object
    $link = GetConnection();
    $exist = False;
    
    if ($link) {

        //Prepared Statement
        $stmt = $link->prepare($query);
        
        //Bind Parameters
        $stmt->bind_param("s", $username);

        //Execute statement
        if (!$stmt->execute()) {
            trigger_error('Error executing MySQL query: ' . $stmt->error);
        }

        //$result = $stmt->get_result();
        // Get the information
        $UserName = "";
        $stmt->bind_result($UserName);
        
        
        while ($stmt->fetch()) { //$row = $result->fetch_assoc()) {
            if($UserName == $username)
                $exist = True;
        }

        $stmt->close();
        $link->close();

    } else {
        printf("Database connection failed!");
    }
    
    return $exist;
}

?>

