<!-- Include Header -->
<?php
require_once 'header.php';
?>

<div class="container-fluid">
    <div class="pagetitle">
        <a>Welcome To My Personal Space</a>
    </div>
</div>
<div class="container-fluid">

    <div class="box">
        <div class="contents" style="margin-top: 65px">
            <h class="text-center">
                </h1>
                <h3>
                    We Just Opened Recently in Orem
                    <small class="text-muted">And We Care About Animals</small>
                </h3>


                <ul class="list-group">
                    <li Class="text-dark" class="display-1" class="list-group-item">Hours and Address:</li>

                    <li class="list-group-item list-group-item-secondary"> Address:300 S St Street Orem, UT</li>
                    <li class="list-group-item list-group-item-secondary">Monday-Tuesday: 9Am-6Pm.</li>
                    <li class="list-group-item list-group-item-secondary">Wednsday-Thursday: 12Am-6Pm.</li>
                    <li class="list-group-item list-group-item-secondary">Saturday:2Pm-5Pm.</li>
                    <li class="list-group-item list-group-item-secondary">Fraiday-Sunday: Closed.</li>
                </ul>

                </br>
        </div>
    </div>
</div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/js/bootstrap.min.js" integrity="sha384-o+RDsa0aLu++PJvFqy8fFScvbHFLtbvScb8AjopnFD+iEQ7wo/CG0xlczd+2O/em"
        crossorigin="anonymous"></script>
</body>

</html>