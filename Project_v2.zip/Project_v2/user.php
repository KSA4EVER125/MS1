<?php
error_reporting(E_ALL);
if (session_id() == NULL) {
    session_start();
}

/**
 * Handle User's Login
 */
require_once 'db.php';

// if login is requested
if (isset($_POST['type']) && $_POST['type'] == "login") {
    $conn = GetConnection();

    $user = filter_var($_POST['loginUsername'], FILTER_SANITIZE_STRING);
    $pass = filter_var($_POST['loginPassword'], FILTER_SANITIZE_STRING);

    $sql = "SELECT username, password, role from users where username=? and password=?";
    echo $user . "<br />". $pass;
    
    // Prepare Statement
    $stmt = $conn->prepare($sql);

    // Bind parameters
    $stmt->bind_param("ss", $user, $pass);

    $FirstName = "";
    $Password = "";
    $Role = "";

    $stmt->bind_result($UserName, $Password, $Role);

    $_SESSION['LoggedIn'] = "False";

    // Execute statement
    if (!$stmt->execute()) {
        trigger_error('Error executing MySQL query: ' . $stmt->error);
    } else {
        while ($stmt->fetch()) {
            // Put into Session
            $_SESSION['UserName'] = $UserName;
            $_SESSION['Role'] = $Role;
            $_SESSION['LoggedIn'] = "True";
            
            if($Role === "Owner")
            {
                $_SESSION['Type'] = "Onwer";
            }
        }
    }

    
    
    $stmt->close();
    $conn->close();
    header("Location: index.php");
} else if (isset($_POST['type']) && $_POST['type'] == "register") {
    $username = filter_var($_POST['registerUsername'], FILTER_SANITIZE_STRING);
    $password = filter_var($_POST['registerPassword'], FILTER_SANITIZE_STRING);
    $firstname = filter_var($_POST['firstname'], FILTER_SANITIZE_STRING);
    $lastname = filter_var($_POST['lastname'], FILTER_SANITIZE_STRING);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_STRING);

    if(GetMember($username) == True)
    {
        $_SESSION['Exist'] = "True";
    }
    else 
    {
        $conn = GetConnection();
        $valid = FALSE;
        $sql = "INSERT INTO users values(?, ?, ?, ?, ?, 'User')";

        // Prepare Statement
        $stmt = $conn->prepare($sql);

        // Bind parameters
        $stmt->bind_param("sssss", $username, $password, $firstname, $lastname, $email);

        // Execute statement
        if (!$stmt->execute()) {
            trigger_error('Error executing MySQL query: ' . $stmt->error);
        }

        $rows_affected = $stmt->affected_rows;

        $stmt->close();
        $conn->close();

        if ($stmt->affected_rows() > 0) {
            $_SESSION['message'] = "Registeration Successful";
        } else {
            $_SESSION['message'] = "Registeration Failed - try again";
        }
    }

    header("Location: index.php");
}

