<!-- Include Header -->
<?php
require_once 'header.php';
?>

<div class="pagetitle">
    <a>Welcome To My Personal Space</a>
</div>
<div class="container-fluid">

    <div class="box">
        <img class="center-block" src="images/Giraffe_standing.jpg" alt="Chania" width="1300" height="600">
        <div class="contents">
            <div class="row">
                <div class="col-md-8" style="margin: 0 auto">
                    <div class="row">
                        <div class="alert alert-success">
                            <?php 
                                if(isset($_SESSION['LoggedIn']))
                                {
                                    if($_SESSION['LoggedIn'] == "True")
                                    {
                                        echo "<h2>Login Successful</h2>";
                                    }
                                    else 
                                    {
                                        echo "<h2>Login Failed</h2>";
                                    }
                                }
                                
                                if(isset($_SESSION['message']))
                                {
                                    echo "<h2>". $_SESSION['message'] . "</h2>";
                                    unset($_SESSION['message']);
                                }
                                
                                if(isset($_SESSION['Exist']))
                                {
                                    echo "<h2>Usename Already taken, try another</h2>";
                                    unset($_SESSION['Exist']);
                                }
                                
                            ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6" style="padding: 20px;">
                            <h2>Login</h2>
                            <form method="post" action="user.php">
                                <div class="form-group">
                                    <label for="loginUsername">UserName</label><br />
                                    <input type="text" class="form-control" name="loginUsername" id="loginUsername" placeholder="UserName" required>
                                </div>
                                <div class="form-group">
                                    <label for="loginPassword">Password</label><br />
                                    <input type="password" required class="form-control" name="loginPassword" id="loginPassword" placeholder="Password" />
                                </div>
                                <input type="hidden" name="type" value="login" />
                                <input type="submit" class="btn btn-lg btn-success" value="Login" />
                            </form>
                        </div>
                        
                        <!--div class="col-md-6"  style="padding: 20px;">
                            <h2>Registration</h2>
                            <form method="post" action="user.php">
                                <div class="form-group">
                                    <label for="registerUsername">UserName</label><br />
                                    <input type="text" class="form-control" name="registerUsername" id="registerUsername" placeholder="registerUsername" required>
                                </div>
                                
                                <div class="form-group">
                                    <label for="registerPassword">Password</label><br />
                                    <input type="password" required class="form-control" name="registerPassword" id="registerPassword" placeholder="Password" />
                                </div>
                                
                                <div class="form-group">
                                    <label for="firstname">First Name</label><br />
                                    <input type="text" required class="form-control" name="firstname" id="firstname" placeholder="first name" />
                                </div>
                                
                                <div class="form-group">
                                    <label for="lastname">Last Name</label><br />
                                    <input type="text" required class="form-control" name="lastname" id="lastname" placeholder="last name" />
                                </div>
                                
                                <div class="form-group">
                                    <label for="email">Email</label><br />
                                    <input type="email" required class="form-control" name="email" id="email" placeholder="Email" />
                                </div>
                                
                                <input type="hidden" name="type" value="register" />
                                <input type="submit" class="btn btn-lg btn-success" value="Register" />
                            </form>
                        </div-->
                    </div>
                </div>
            </div>            
            <h class="text-center">
                </h1>
                <h3>
                    Come Adopt A Pet
                    <small class="text-muted">And Together Lets Make The World A better place</small>
                </h3>
                <ul class="list-dark">
                    <li Class="text-secondary" class="font-weight-bold" class="list-group-item">Famous Qoutes About Pets</li>

                    <li class="list-group-item list-group-item-secondary">"Until one has loved an animal, a part of one's soul remains unawakened." ― Anatole France</li>
                    <li class="list-group-item list-group-item-secondary">"If having a soul means being able to feel love and loyalty and gratitude, then animals are better
                        off than a lot of humans."―James Herriot</li>
                    <li class="list-group-item list-group-item-secondary">"The greatness of a nation and its moral progress can be judged by the way its animals are treated."
                        ― Mahatma Gandhi</li>
                    <li class="list-group-item list-group-item-secondary">"An animal's eyes have the power to speak a great language." ― Martin Buber</li>
                    <li class="list-group-item list-group-item-secondary">"“I care not for a man's religion whose dog and cat are not the better for it.” ― Abraham Lincoln</li>
                </ul>

                </br>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/js/bootstrap.min.js" integrity="sha384-o+RDsa0aLu++PJvFqy8fFScvbHFLtbvScb8AjopnFD+iEQ7wo/CG0xlczd+2O/em"
crossorigin="anonymous"></script>
</body>

</html>