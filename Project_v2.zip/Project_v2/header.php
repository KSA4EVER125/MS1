<?php

if(session_id() == NULL)
{
    session_start();
}


?>

<!doctype html>
<html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/css/bootstrap.min.css" integrity="sha384-Smlep5jCw/wG7hdkwQ/Z5nLIefveQRIY9nfy6xoR1uRYBtpZgI6339F5dgvm/e9B"
              crossorigin="anonymous">
        <title>Welcome to Our Home Page</title>
    </head>

    <body>

        <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark fixed-top">
            <div class="container">
                <a class="navbar-brand" href="index.php">Paws to Care</a>
                <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive"
                        aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.php">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">Contact Us</a>
                        </li>
                        
                        <?php
                            if(isset($_SESSION['LoggedIn']) && $_SESSION['LoggedIn'] == "True") {
                        ?>
                        
                        <?php 
                            if($_SESSION['Role'] == "Admin") {
                        ?>
                        <li class="nav-item">
                            <a class="nav-link" href="dogA.php">Dogs</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="catA.php">Cats</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="ExoticsA.php">Exotics</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="owners.php">Owners</a>
                        </li>
                            <?php 
                            }
                            ?>
                        
                        <?php 
                            if($_SESSION['Role'] == "Owner") {
                        ?>
                        
                        <li class="nav-item">
                            <a class="nav-link" href="pets.php">Pets</a>
                        </li>
                            <?php 
                            }
                            ?>
                        
                        <li class="nav-item">
                            <a class="nav-link btn-danger"  href="logout.php">Logout</a>
                        </li>
                        
                        <?php
                            
                            }
                            
                             ?>
                    </ul>
                </div>
            </div>
        </nav>

