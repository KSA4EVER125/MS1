<?php
if (session_id() == NULL) {
    session_start();
}

require_once 'db.php';

/**
 * Database layer - Read the Query String and return the data in JSon format
 */

if(isset($_GET['type']))
{
    // Get the query string
    $param = $_GET['type'];
    
    // Get Connection
    $conn = GetConnection();
    
    $type = $_GET['type'];
    
    $resultSet = array();
    
    if($type === "exotics")
    {
        $sql = "SELECT e.name, e.species, e.sex, (TIMESTAMPDIFF(YEAR, e.birthdate, Now()) + 1) as age, e.neutered, concat(o.fname, ' ', o.lname) 
                as owners, en.note as notes FROM exotics e, owners o, exoticsowners co, exoticnotes en 
                where e.id =    co.id 
                and o.id = co.id
                and e.id = en.id";
        $result = $conn->query($sql);
        $resultSet = $result->fetch_all(MYSQLI_ASSOC);
        echo json_encode($resultSet);
    }
    else if($type === "dogs")
    {
        $sql = "SELECT d.name, d.breed, d.sex, d.shots, (TIMESTAMPDIFF(YEAR, d.birthdate, Now()) + 1) as age, d.size, d.licensed, d.neutered, concat(o.fname, ' ', o.lname) 
                as owners, dn.note as notes FROM dogs d, owners o, dogsowners do, dogNotes dn 
                where d.id =    do.id 
                and o.id = do.id
                and d.id = dn.id";
                
        $result = $conn->query($sql);
        $resultSet = $result->fetch_all(MYSQLI_ASSOC);
        echo json_encode($resultSet);
    }
    else if($type === "cats")
    {
        $sql = "SELECT c.name, c.breed, c.sex, c.shots, (TIMESTAMPDIFF(YEAR, c.birthdate, Now()) + 1) as age, c.declawed, c.neutered, concat(o.fname, ' ', o.lname) 
                as owners, cn.note as notes FROM cats c, owners o, catsowners co, catnotes cn 
                where c.id =  co.id 
                and o.id = co.id
                and c.id = cn.id";
        
        $result = $conn->query($sql);
        $resultSet = $result->fetch_all(MYSQLI_ASSOC);
        echo json_encode($resultSet);
    }
    else if($type == "owners")
    {
        $output = "";
        $sql = "select * from owners";
       $output = "<table class='table table-hover table-striped'";
        $output .= "<thead>
                    <tr class='thead-dark'>
                      <th>First Name</th>
                      <th>Last Name</th>
                      <th>Addrees</th>
                      <th>City</th>
                      <th>State</th>
                      <th>Zip</th>
                    </tr>
                    </thead><tbody>";
        $result = $conn->query($sql);
        while($row = $result->fetch_assoc())
        {
            $output .= "<tr>";
            $output .= "<td>". $row['fname'] ."</div>";
            $output .= "<td>". $row['lname'] ."</div>";
            $output .= "<td>". $row['add1'] . ' '. $row['add2'] ."</div>";
            $output .= "<td>". $row['city'] ."</div>";
            $output .= "<td>". $row['st'] ."</div>";
            $output .= "<td>". $row['zip'] ."</div>";
            $output .= "</tr>";
        }
        
        $output .= "</tbody></table>";
        echo $output;
    }
    else if($type == "pets")
    {
        $UserName = $_SESSION['UserName']; 
        
        // Get dogs
        $sql = "SELECT d.name, d.breed, d.sex, d.shots, (TIMESTAMPDIFF(YEAR, d.birthdate, Now()) + 1) as age, d.size, d.licensed, d.neutered 
                FROM dogs d, owners o, dogsowners do, dogNotes dn 
                where d.id =    do.id 
                and o.id = do.id
                and d.id = dn.id
                AND O.UserName='". $UserName . "'";
        
        $result = $conn->query($sql);
        
        
        $output = "<div class='container'>";
        $output .= "<h2>Dogs</h2><br />";
        $output .= "<div class='row' style='background-color: black; color: white'>";
        $output .= "<div class='col'><h3>Name</h3></div>";
        $output .= "<div class='col'><h3>breed</h3></div>";
        $output .= "<div class='col'><h3>Sex</h3></div>";
        $output .= "<div class='col'><h3>Shots</h3></div>";
        $output .= "<div class='col'><h3>Age</h3></div>";
        $output .= "<div class='col'><h3>Size</h3></div>";
        $output .= "<div class='col'><h3>Licensed</h3></div>";
        $output .= "<div class='col'><h3>Neutered</h3></div>";
        $output .= "</div>";
        $counter = 0;
        
        while($row = $result->fetch_assoc())
        {
            $output .= "<div class='row' style='background-color: #eee; color: Black'>";
            /*
            if($counter % 2 == 0)
            {
                
            }
            else 
            {
                $output .= "<div class='row' style='background-color: #ddd; color: Black'>";
            }*/
            
            $output .= "<div class='col'>". $row['name'] ."</div>";
            $output .= "<div class='col'>". $row['breed'] ."</div>";
            $output .= "<div class='col'>". $row['sex'] ."</div>";
            $output .= "<div class='col'>". yn($row['shots']) ."</div>";
            $output .= "<div class='col'>". $row['age'] ."</div>";
            $output .= "<div class='col'>". $row['size'] ."</div>";
            $output .= "<div class='col'>". yn($row['licensed']) ."</div>";
            $output .= "<div class='col'>". yn($row['neutered']) ."</div>";
            $output .= "</div>";
            $counter++;
        }
        $output .= "</div>";
        
       // Get Cats
       $sql = "SELECT c.name, c.breed, c.sex, c.shots, (TIMESTAMPDIFF(YEAR, c.birthdate, Now()) + 1) as age, c.declawed, c.neutered
                FROM cats c, owners o, catsowners co, catnotes cn 
                where c.id =  co.id 
                and o.id = co.id
                and c.id = cn.id
                and o.UserName = '". $UserName . "'";
        
        $result = $conn->query($sql);
        $output .= "<br /><br />";
        
        $output .= "<div class='container'>";
        $output .= "<h2>Cats</h2><br />";
        $output .= "<div class='row' style='background-color: black; color: white'>";
        $output .= "<div class='col'><h3>Name</h3></div>";
        $output .= "<div class='col'><h3>breed</h3></div>";
        $output .= "<div class='col'><h3>Sex</h3></div>";
        $output .= "<div class='col'><h3>Shots</h3></div>";
        $output .= "<div class='col'><h3>Age</h3></div>";
        $output .= "<div class='col'><h3>Declawed</h3></div>";
        $output .= "<div class='col'><h3>Neutered</h3></div>";
        $output .= "</div>";
        
        while($row = $result->fetch_assoc())
        {
            $output .= "<div class='row' style='background-color: #eee; color: Black'>";
            $output .= "<div class='col'>". $row['name'] ."</div>";
            $output .= "<div class='col'>". $row['breed'] ."</div>";
            $output .= "<div class='col'>". $row['sex'] ."</div>";
            $output .= "<div class='col'>". yn($row['shots']) ."</div>";
            $output .= "<div class='col'>". $row['age'] ."</div>";
            $output .= "<div class='col'>". yn($row['declawed']) ."</div>";
            $output .= "<div class='col'>". yn($row['neutered']) ."</div>";
            $output .= "</div>";
            $counter++;
        }
        
        $output .= "</div>";
        $output .= "<br /><br />";
        
        $sql = "SELECT e.name, e.species, e.sex, (TIMESTAMPDIFF(YEAR, e.birthdate, Now()) + 1) as age, e.neutered
                FROM exotics e, owners o, exoticsowners co, exoticnotes en 
                where e.id =    co.id 
                and o.id = co.id
                and e.id = en.id
                and o.UserName='" . $UserName . "'";
        
        $result = $conn->query($sql);
        
        $output .= "<div class='container'>";
        $output .= "<h2>Exotics</h2><br />";
        $output .= "<div class='row' style='background-color: black; color: white'>";
        $output .= "<div class='col'><h3>Name</h3></div>";
        $output .= "<div class='col'><h3>Species</h3></div>";
        $output .= "<div class='col'><h3>Sex</h3></div>";
        $output .= "<div class='col'><h3>Age</h3></div>";
        $output .= "<div class='col'><h3>Neutered</h3></div>";
        $output .= "</div>";
        
        while($row = $result->fetch_assoc())
        {
            $output .= "<div class='row' style='background-color: #eee; color: Black'>";
            $output .= "<div class='col'>". $row['name'] ."</div>";
            $output .= "<div class='col'>". $row['species'] ."</div>";
            $output .= "<div class='col'>". $row['sex'] ."</div>";
            $output .= "<div class='col'>". $row['age'] ."</div>";
            $output .= "<div class='col'>". yn($row['neutered']) ."</div>";
            $output .= "</div>";
            $counter++;
        }
        $output .= "</div>";
        
        $conn->close();
        echo $output;
    }
}

function yn($value) {
    $yes = "<span style='font-family: wingdings; color: lime; font-size: 200%;'>&#x1F5F9;</span>";
    $no = "<span style='font-family: wingdings; color: black; font-size: 200%;'>&#x1F5F5;</span>";
    return ($value == 1) ? $yes : $no;
}

?>

