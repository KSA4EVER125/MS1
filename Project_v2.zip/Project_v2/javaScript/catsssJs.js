const columns = ["name",
    "breed",
    "sex",
    "shots",
    "age",
    "declawed",
    "neutered",
    "owners",
    "notes"];

const symbols = {
    "up": '&#8597;',
    "down": '&darr;',
    "unset": '&nbsp;&nbsp;'
};
const sorts = { // initally all sorts not effective
    "name": null,
    "breed": null,
    "sex": null,
    "shots": null,
    "age": null,
    "declawed": null,
    "neutered": null,
    "owners": null,
    "notes": null

};
const alpha = function (a, b) {
    if (a === b) return 0;
    if (a < b) return -1;
    return 1;
};
const numeric = function (a, b) {
    if (a === b) return 0;
    if (parseInt(a) < parseInt(b)) return -1;
    return 1;
};
const columnFunc = {


    "name": {
        col: 0,
        func: alpha,
         filter: true,
        title: "The cat Name"
    },
    "breed": {
        col: 1,
        func: alpha,
         filter: true,
        title: "The cat breed"
    },
    "sex": {
        col: 2,
        func: alpha,
         filter: true,
        title: "The cat sex"
    },
    "shots": {
        col: 3,
        func: alpha,
        render: yn,
         filter: true,
        title: "The cat shots"
    },
    "age": {
        col: 4,
        func: numeric,
         filter: true,
        title: "The cat age"
    },
    "declawed": {
        col: 5,
        func: alpha,
        render: yn,
         filter: true,
        title: "If the Cat declawed"
    },
    "neutered": {
        col: 6,
        func: alpha,
        render: yn,
         filter: true,
        title: "If the Cat neutered"
    },
    "owners": {
        col: 7,
        title: false,
        filter: false,
        func: false,
        modal: true,
        title: "The cat owners"
    },
    "notes": {
        col: 8,
        title: false,
        filter: false,
        func: false,
        modal: true,
        title: "The cat notes"
    }
}
const filters = {};
//variables
var petss = [];
var petsSize = 3;

//Description: This is main function
//Parameters: nothing.
//Return: nothing.
$(document).ready(function () {
    let petss = petsAja(petsSize);
});

//Description: This creates objects and check JSON
//Parameters: number of petss
//Return: nothing
function petsAja(petsCount) {
    let petss = [];
    var sizeL = null;
    $.ajax({
        'type': 'GET',
        'Content-Type': "application/json",
        'url': `collect.php?type=cats`,
        'success': function (getTable) {
            sizeL = getTable;
            let loadT = 0;
            for (let i = 0; i < Math.min(petsCount, sizeL.length); i++) {
                let petK = null;
                $.ajax({
                    'type': 'GET',
                    'url': `collect.php?type=cats`,
                    'success': function (getTable) {
                        setTimeout(function () {
                            loadT++;
                            petK = getTable;
                            petK.name = sizeL[1];
                            petss.push(petK);
                            if (petss.length === Math.min(petsCount)) {
                                console.log('done loading json');
                                printTable(petss);
                            }

                        }, 5);

                    }
                });
            }

        }
    });

}


//Description:
//Parameters: 
//Return: 
function printTable(petss) {
    $.getJSON("collect.php?type=cats", function (getTable) {
        buildTable(getTable);

    });

}

function buildTable(petss) {


    let numPets = petss.length;
    let table = $('table').empty();
    let thead = $('<thead class="thead-light"/>');
    thead.append($('<tr/>').append(columns.map(colName => {
        if (columnFunc[colName].filter) {
            return $('<th scope="col"><input style="width:75px" id="' + colName + '"></th>');

        }
        else {
            return $('<th scope="col"></th>');

        }
    }
    )));
    thead.append($('<tr/>').append(columns.map(colName => {
        let capName = colName.charAt(0).toUpperCase() + colName.substr(1);
        let th = '<th scope="col"  class="dir" style="text-align:left; cursor:pointer" ' +
         
         'col="' +colName + '">' + 
         '<span data-toggle="tooltip" data-placement="bottom" title="' + columnFunc[colName].title +
          '">' + capName + '</span>';
        if (columnFunc[colName].func !== false) {
            th += '&nbsp;&nbsp;<span class="srt" ></span>';
        }
        th += '</th>';
        return th;
    })));
    table.append(thead);
    let tbody = $('<tbody/>');
    for (let row = 0; row < numPets; row++) {
        let tds =
            columns.map(
                (colName) => {
                    let value = petss[row][colName];
                    if (columnFunc[colName].modal === true) {
                        let capName = colName.charAt(0).toUpperCase() + colName.substr(1);
                        value = '<button type="button" class="modal_button btn btn-info btn-sm" ' +
                            'body="' + value + '" ' +
                            'text="' + capName + '" ' +
                            'data-toggle="modal" data-target="#myModal">' + colName + '</button>';

                    }
                    else if (columnFunc[colName].render !== undefined) {
                        value = columnFunc[colName].render(value);
                    }
                    return $('<td>' + value + '</td>');
                });
        tbody.append($('<tr/>').append(tds));
    }
    table.append(tbody);
    $('.modal_button').on('click', (e) => {
        let button = $(e.target);
        $('.modal-body').text(button.attr('body'));
        $('.modal-title').text(button.attr('text'));

    });
    showDirSorting();
    $('.dir').on('click', (e) => {
        let colName = $(e.target).closest('th').attr('col');
        if (sorts[colName] === null) {
            sorts[colName] = true; // 'asc' (down arrow)
        } else {
            sorts[colName] = !sorts[colName]; // reverse sort direction
        }

        showDirSorting(colName);
        sortTable(colName);
    });
    $('input').on('input', (e) => {
        let pattern = $(e.target).val().toLowerCase();
        let id = $(e.target).attr('id');
        filters[id] = pattern;
        filterTable();
    });

}

function yn(value) {
       var yes = '<span style="font-family: wingdings; color: lime; font-size: 200%;">&#x1F5F9;</span>'
    var no = '<span style="font-family: wingdings; color: black; font-size: 200%;">&#x1F5F5;</span>'
    return (value == 1) ? yes : no;
}
function filterPet(aPet) {
    let result = true;
    Object.keys(filters).forEach(
        (tag) => {
            if (dataTypes[tag] === 'alpha') {
                let str = aPet[tag];
                if (tag === 'size') {
                    str = aPet[tag]; //dogSize(aPet[tag]);
                }
                // can also ignore case
                if (str.indexOf(filters[tag]) === -1) return false;
            } else if (dataTypes[tag] === 'boolean') {
                if (yn(aPet[tag]) !== filters[tag].toUpperCase()) return false;
            } else { // numeric
                let str = aPet[tag] + "";
                if (str.indexOf(filters[tag]) === -1) return false;
            }
        }
    )
    return true;
}

//Description: describe size of dog from its weight
//Parameters: size
//Return: string
/*
function dogSize(size) {
    if (size < 20) {
        return "S";
    } else if (size < 50) {
        return "M";
    } else {
        return "L";
    }
}*/


function showDirSorting(colName) {
    $(".srt").html(symbols.unset); // set all to unset
    if (colName !== undefined) {
        $('th[col=' + colName + ']').find('.srt').html(sorts[colName] ? symbols.down : symbols.up);
    }
}
function sortTable(colName) {
    let dir = sorts[colName]; // boolean true ascending, false descending

    let sortedRows = $('tbody tr').toArray().sort((row_a, row_b) => {
        let col_a = $(row_a).find('td').get(columnFunc[colName].col).textContent;
        let col_b = $(row_b).find('td').get(columnFunc[colName].col).textContent;
        let result = columnFunc[colName].func(col_a, col_b)
        return (sorts[colName]) ? result : -result; // asc vs des
    });
    refillTable(sortedRows);
    filterTable();
}
function filterTable() {
    $('tbody > tr').show().each(
        (index, tr) => {
            tr = $(tr);
            let tds = tr.find('td');
            columns.forEach(
                (cName, cidx) => {
                    let pat = filters[cName];
                    let tdtext = $(tds.get(cidx)).text().toLowerCase();

                    if (pat !== undefined && pat != "") { // pattern exists and is not empty
                        //if (!tdtext.includes(pat)) { // test for overlaps of characters (even for numbers)
                        if(!tdtext.startsWith(pat)) {
                            tr.hide();
                        }
                    }
                }
            );
        }
    )
}
function refillTable(sortedRows) {
    let tbody = $('tbody').empty();
    sortedRows.forEach(
        row => {
            tbody.append($(row));
        }
    );
}