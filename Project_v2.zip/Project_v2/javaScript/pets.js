/**
 * Function to load the Pets for the logged in Owner. 
 * 
 * @param {type} petsCount
 * @returns {undefined}
 */
function load() {
    let petss = [];
    var sizeL = null;
    $.ajax({
        'type': 'GET',
        'Content-Type': "application/json",
        'url': `collect.php?type=pets`,
        'success': function (result) {
            $("#data").html(result);
        }
    });
}

//Description: This is main function
//Parameters: nothing.
//Return: nothing.
$(document).ready(function () {
    load();
});
