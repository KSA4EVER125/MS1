/**
 * Function to load the Pets for the logged in Owner. 
 * 
 * @param {type} petsCount
 * @returns {undefined}
 */
function load() {
     $.ajax({url: "collect.php?type=owners", success: function(result){
        $("#data").append(result);
    }});
}

//Description: This is main function
//Parameters: nothing.
//Return: nothing.
$(document).ready(function () {
    load();
});

